import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DataStore extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DataStore frame = new DataStore();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	//Main window
	public DataStore() {
		setTitle("Data Storage");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel lblNewLabel = new JLabel("What would you like to do?");
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel, 143, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblNewLabel, -203, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblNewLabel);
		
		JButton btnRetrieveData = new JButton("Retrieve data");
		btnRetrieveData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RetrieveData retrieve_data = new RetrieveData();
			}
		});
		contentPane.add(btnRetrieveData);
		
		
		
		JButton btnAddData = new JButton("Add data");
		sl_contentPane.putConstraint(SpringLayout.WEST, btnRetrieveData, 0, SpringLayout.WEST, btnAddData);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnRetrieveData, 0, SpringLayout.EAST, btnAddData);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnAddData, 158, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnAddData, -157, SpringLayout.EAST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnAddData, 6, SpringLayout.SOUTH, lblNewLabel);
		btnAddData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddData add_data = new AddData();
			}
		});
		contentPane.add(btnAddData);
		
		JButton btnUpdateData = new JButton("Update data");
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnUpdateData, 10, SpringLayout.SOUTH, btnAddData);
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnRetrieveData, 10, SpringLayout.SOUTH, btnUpdateData);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnUpdateData, 0, SpringLayout.WEST, btnRetrieveData);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnUpdateData, -157, SpringLayout.EAST, contentPane);
		btnUpdateData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateData updateData = new UpdateData();
			}
		});
		contentPane.add(btnUpdateData);
		
		JButton btnDeleteData = new JButton("Delete data");
		btnDeleteData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteData deleteData = new DeleteData();
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnDeleteData, 10, SpringLayout.SOUTH, btnRetrieveData);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnDeleteData, 0, SpringLayout.WEST, btnRetrieveData);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnDeleteData, 0, SpringLayout.EAST, btnRetrieveData);
		contentPane.add(btnDeleteData);
	}
}
