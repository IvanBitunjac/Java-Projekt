
public class UpdateQueries {
	private String columnName;
	private String data;
	private String query;
	private int userID;
	
	public UpdateQueries(String columnName, String data, String userID) {
		this.columnName = columnName;
		this.data = data;
		this.userID = Integer.parseInt(userID);
		query = "UPDATE Users SET " + this.columnName + " = " + "'" + data + "'" + " WHERE userID = " + userID;
	}
	
	public String GetQuery() {
		return this.query;
	}
	
	public String GetColumnName() {
		return this.columnName;
	}
	
	public String GetData() {
		return this.data;
	}
	
}
