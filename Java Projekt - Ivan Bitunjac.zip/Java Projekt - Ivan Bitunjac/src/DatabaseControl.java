import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


public class DatabaseControl {
	String driver = "com.mysql.cj.jdbc.Driver";
	//Poveznica na lokalnu bazu podataka
	String url = "jdbc:mysql://localhost/javaproject?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	String username = "root";
	String password = "dn84Malsr";
	private PreparedStatement query;
	private ResultSet result;
	private Connection con;
	
	//Ostvaruje vezu na lokalnu bazu
	public Connection getConnection() throws Exception {
		try {
			Class.forName(driver);
			Connection database_con = DriverManager.getConnection(url, username, password);
			return database_con;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	public ResultSet GetResult() {
		return this.result;
	}
	
	
	//Dodaje podatke u bazu, povratna vrijednost je jedinstveni ID tog user-a
	public int AddUserData(String username, String name, String surname, String email, String password, String platform, String securityQuestionAnswer) throws Exception{
		
		try {
			con = getConnection();
			//Uzima se zadnje dodjeljeni ID iz tablice, uve�ava se za 1 i dodjeljuje se novom user-u
			query = con.prepareStatement("SELECT userID FROM Users ORDER BY userID DESC LIMIT 1;");
			result = query.executeQuery();
			result.next();
			int counter = result.getInt("userID") + 1;
			query = con.prepareStatement("INSERT INTO Users VALUES ('"+username+"' , '"+name+"' , '"+surname+"' , '"+email+"' , '"+password+"' , '"+platform+"' , '"+securityQuestionAnswer+"' , '"+counter+"')");
			query.execute();
			return counter;
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return 0;
		}
	}
	
	
	//Dohva�a podatke iz baze po user ID-u
	public boolean GetUserData(int userID) throws Exception, SQLException {
		try {
			con = getConnection();
			query = con.prepareStatement("SELECT * FROM Users WHERE userID=" + userID);
			result = query.executeQuery();
			if(result.next() == false)
				return false;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return true;
	}
	
	
	//A�urira podatke u baze pozivom UpdateQueries klase
	public void UpdateUserData(List<UpdateQueries> dataToUpdate) throws SQLException, Exception{
		try {
			con = getConnection();
			//Prolazi kroz kontrole u prozoru te gleda koje su ispunjene te njih a�urira u bazi
			for(UpdateQueries element : dataToUpdate) {
				if(element.GetData() == null || element.GetData() == "")
					continue;
				query = con.prepareStatement(element.GetQuery());
				query.executeUpdate();
			}
		}
		catch(SQLException sqlEx) {
			System.out.println(sqlEx.getMessage());
			sqlEx.printStackTrace();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	//Bri�e red podataka u bazi s proslje�enim ID-om
	public String DeleteUserData(int userID) throws SQLException, Exception {
		try {
			con = getConnection();
			query = con.prepareStatement("SELECT userID FROM Users ORDER BY userID DESC LIMIT 1;");
			result = query.executeQuery();
			result.next();
			int counter = result.getInt("userID");
			//Ako je proslje�eni ID ve�i od zadnjeg dodjeljenog ID-a taj user ne postoji
			if(userID > counter) {
				return "No such user";
			}
			else {
				query = con.prepareStatement("DELETE FROM Users WHERE userID=" + userID);
				query.execute();
				return "Data deleted";
			}
		}
		catch(SQLException sqlEx) {
			System.out.println(sqlEx.getMessage());
			sqlEx.printStackTrace();
			return "SQL Exception";
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return "Exception";
		}
	}
}
