import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;
import java.awt.event.ActionEvent;

public class UpdateData extends JFrame {

	private DatabaseControl databaseControl = new DatabaseControl();
    private List<UpdateQueries> dataToUpdate = new ArrayList<UpdateQueries>();
	private JPanel contentPane = new JPanel();;
	private SpringLayout springLayout = new SpringLayout();
	private JTextField usernameTextfield;
	private JTextField nameTextfield;
	private JTextField surnameTextfield;
	private JTextField emailTextfield;
	private JTextField passwordTextfield;
	private JTextField platformTextfield;
	private JTextField sqaTextfield;
	private JTextField userIDTextfield;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public UpdateData() {
		setTitle("Update data");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(600, 600);
		setContentPane(contentPane);
		contentPane.setLayout(springLayout);
		
		JLabel usernameLabel = new JLabel("Username:");
		contentPane.add(usernameLabel);
		
		usernameTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, usernameTextfield, -3, SpringLayout.NORTH, usernameLabel);
		springLayout.putConstraint(SpringLayout.WEST, usernameTextfield, 30, SpringLayout.EAST, usernameLabel);
		springLayout.putConstraint(SpringLayout.EAST, usernameTextfield, -379, SpringLayout.EAST, contentPane);
		contentPane.add(usernameTextfield);
		usernameTextfield.setColumns(10);
		
		JLabel nameLabel = new JLabel("Name:");
		springLayout.putConstraint(SpringLayout.NORTH, nameLabel, 18, SpringLayout.SOUTH, usernameLabel);
		springLayout.putConstraint(SpringLayout.WEST, usernameLabel, 0, SpringLayout.WEST, nameLabel);
		contentPane.add(nameLabel);
		
		JLabel surnameLabel = new JLabel("Surname:");
		springLayout.putConstraint(SpringLayout.WEST, surnameLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(surnameLabel);
		
		JLabel emailLabel = new JLabel("Email:");
		springLayout.putConstraint(SpringLayout.NORTH, emailLabel, 138, SpringLayout.NORTH, contentPane);
		springLayout.putConstraint(SpringLayout.SOUTH, surnameLabel, -16, SpringLayout.NORTH, emailLabel);
		springLayout.putConstraint(SpringLayout.WEST, emailLabel, 10, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.EAST, nameLabel, 0, SpringLayout.EAST, emailLabel);
		contentPane.add(emailLabel);
		
		JLabel labelPassword = new JLabel("Password:");
		springLayout.putConstraint(SpringLayout.NORTH, labelPassword, 20, SpringLayout.SOUTH, emailLabel);
		springLayout.putConstraint(SpringLayout.WEST, labelPassword, 10, SpringLayout.WEST, contentPane);
		contentPane.add(labelPassword);
		
		JLabel platformLabel = new JLabel("Platform:");
		springLayout.putConstraint(SpringLayout.WEST, platformLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(platformLabel);
		
		JLabel labelSQA = new JLabel("SQA:");
		springLayout.putConstraint(SpringLayout.NORTH, labelSQA, 245, SpringLayout.NORTH, contentPane);
		springLayout.putConstraint(SpringLayout.WEST, labelSQA, 10, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.SOUTH, platformLabel, -22, SpringLayout.NORTH, labelSQA);
		contentPane.add(labelSQA);
		
		nameTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, nameTextfield, -3, SpringLayout.NORTH, nameLabel);
		springLayout.putConstraint(SpringLayout.WEST, nameTextfield, 89, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.EAST, nameTextfield, 0, SpringLayout.EAST, usernameTextfield);
		nameTextfield.setColumns(10);
		contentPane.add(nameTextfield);
		
		surnameTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, surnameTextfield, -3, SpringLayout.NORTH, surnameLabel);
		springLayout.putConstraint(SpringLayout.WEST, surnameTextfield, 89, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.EAST, surnameTextfield, 0, SpringLayout.EAST, usernameTextfield);
		surnameTextfield.setColumns(10);
		contentPane.add(surnameTextfield);
		
		emailTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, emailTextfield, -3, SpringLayout.NORTH, emailLabel);
		springLayout.putConstraint(SpringLayout.WEST, emailTextfield, 89, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.EAST, emailTextfield, 0, SpringLayout.EAST, usernameTextfield);
		emailTextfield.setColumns(10);
		contentPane.add(emailTextfield);
		
		passwordTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, passwordTextfield, -3, SpringLayout.NORTH, labelPassword);
		springLayout.putConstraint(SpringLayout.WEST, passwordTextfield, 89, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.EAST, passwordTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(passwordTextfield);
		passwordTextfield.setColumns(10);
		
		platformTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, platformTextfield, -3, SpringLayout.NORTH, platformLabel);
		springLayout.putConstraint(SpringLayout.WEST, platformTextfield, 35, SpringLayout.EAST, platformLabel);
		springLayout.putConstraint(SpringLayout.EAST, platformTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(platformTextfield);
		platformTextfield.setColumns(10);
		
		sqaTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, sqaTextfield, -3, SpringLayout.NORTH, labelSQA);
		springLayout.putConstraint(SpringLayout.WEST, sqaTextfield, 54, SpringLayout.EAST, labelSQA);
		springLayout.putConstraint(SpringLayout.EAST, sqaTextfield, 0, SpringLayout.EAST, usernameTextfield);
		sqaTextfield.setColumns(10);
		contentPane.add(sqaTextfield);
		
		JButton buttonUpdateData = new JButton("Update");
		springLayout.putConstraint(SpringLayout.NORTH, buttonUpdateData, 13, SpringLayout.SOUTH, sqaTextfield);
		buttonUpdateData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int userID = Integer.parseInt(userIDTextfield.getText());
				dataToUpdate.add(new UpdateQueries("username", usernameTextfield.getText(), userIDTextfield.getText()));
				dataToUpdate.add(new UpdateQueries("name", nameTextfield.getText(), userIDTextfield.getText()));
				dataToUpdate.add(new UpdateQueries("surname", surnameTextfield.getText(), userIDTextfield.getText()));
				dataToUpdate.add(new UpdateQueries("email", emailTextfield.getText(), userIDTextfield.getText()));
				dataToUpdate.add(new UpdateQueries("password", passwordTextfield.getText(), userIDTextfield.getText()));
				dataToUpdate.add(new UpdateQueries("platform", platformTextfield.getText(), userIDTextfield.getText()));
				dataToUpdate.add(new UpdateQueries("securityQuestionAnswer", sqaTextfield.getText(), userIDTextfield.getText()));
				try {
					databaseControl.UpdateUserData(dataToUpdate);
				    JOptionPane.showMessageDialog(null, "Data updated successfully!");
				} catch (Exception e1) {
					System.out.println(e1.getMessage());
					e1.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, buttonUpdateData, 87, SpringLayout.WEST, contentPane);
		contentPane.add(buttonUpdateData);
		
		JLabel labelUserID = new JLabel("User ID:");
		springLayout.putConstraint(SpringLayout.NORTH, usernameLabel, 17, SpringLayout.SOUTH, labelUserID);
		springLayout.putConstraint(SpringLayout.NORTH, labelUserID, 10, SpringLayout.NORTH, contentPane);
		springLayout.putConstraint(SpringLayout.WEST, labelUserID, 0, SpringLayout.WEST, usernameLabel);
		contentPane.add(labelUserID);
		
		userIDTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, userIDTextfield, -3, SpringLayout.NORTH, labelUserID);
		springLayout.putConstraint(SpringLayout.WEST, userIDTextfield, 40, SpringLayout.EAST, labelUserID);
		springLayout.putConstraint(SpringLayout.EAST, userIDTextfield, 0, SpringLayout.EAST, buttonUpdateData);
		contentPane.add(userIDTextfield);
		userIDTextfield.setColumns(10);
	}
}
