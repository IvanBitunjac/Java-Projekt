import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddData extends JFrame {

	DatabaseControl dbControl = new DatabaseControl();
	
	private JPanel contentPane;
	private SpringLayout spring_layout;
	private JTextField nameTextfield;
	private JTextField surnameTextfield;
	private JTextField emailTextfield;
	private JTextField passwordTextfield;
	private JTextField platformTextfield;
	private JTextField sqaTextfield;
	

	/**
	 * Create the frame.
	 */
	public AddData() {
		setTitle("Add data");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(600, 600);
		contentPane = new JPanel();
		spring_layout = new SpringLayout();
		setContentPane(contentPane);
		contentPane.setLayout(spring_layout);
		
		JLabel usernameLabel = new JLabel("Username:");
		spring_layout.putConstraint(SpringLayout.WEST, usernameLabel, 5, SpringLayout.WEST, contentPane);
		spring_layout.putConstraint(SpringLayout.NORTH, usernameLabel, 10, SpringLayout.NORTH, contentPane);
		contentPane.add(usernameLabel);
		
		JTextField usernameTextfield = new JTextField();
		spring_layout.putConstraint(SpringLayout.WEST, usernameTextfield, 10, SpringLayout.EAST, usernameLabel);
		spring_layout.putConstraint(SpringLayout.NORTH, usernameTextfield, 10, SpringLayout.NORTH, contentPane);
		spring_layout.putConstraint(SpringLayout.EAST, usernameTextfield, 198, SpringLayout.EAST, usernameLabel);
		contentPane.add(usernameTextfield);
		
		JLabel nameLabel = new JLabel("Name:");
		spring_layout.putConstraint(SpringLayout.WEST, nameLabel, 5, SpringLayout.WEST, contentPane);
		spring_layout.putConstraint(SpringLayout.NORTH, nameLabel, 12, SpringLayout.SOUTH, usernameLabel);
		contentPane.add(nameLabel);
		
		nameTextfield = new JTextField();
		spring_layout.putConstraint(SpringLayout.NORTH, nameTextfield, 6, SpringLayout.SOUTH, usernameTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, nameTextfield, 0, SpringLayout.WEST, usernameTextfield);
		spring_layout.putConstraint(SpringLayout.EAST, nameTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(nameTextfield);
		
		JLabel lblSurname = new JLabel("Surname:");
		spring_layout.putConstraint(SpringLayout.NORTH, lblSurname, 12, SpringLayout.SOUTH, nameLabel);
		spring_layout.putConstraint(SpringLayout.WEST, lblSurname, 0, SpringLayout.WEST, usernameLabel);
		spring_layout.putConstraint(SpringLayout.EAST, lblSurname, 0, SpringLayout.EAST, usernameLabel);
		contentPane.add(lblSurname);
		
		surnameTextfield = new JTextField();
		spring_layout.putConstraint(SpringLayout.NORTH, surnameTextfield, 6, SpringLayout.SOUTH, nameTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, surnameTextfield, 0, SpringLayout.WEST, usernameTextfield);
		spring_layout.putConstraint(SpringLayout.EAST, surnameTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(surnameTextfield);
		
		emailTextfield = new JTextField();
		spring_layout.putConstraint(SpringLayout.NORTH, emailTextfield, 6, SpringLayout.SOUTH, surnameTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, emailTextfield, 0, SpringLayout.WEST, usernameTextfield);
		spring_layout.putConstraint(SpringLayout.EAST, emailTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(emailTextfield);
		
		passwordTextfield = new JTextField();
		spring_layout.putConstraint(SpringLayout.NORTH, passwordTextfield, 6, SpringLayout.SOUTH, emailTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, passwordTextfield, 0, SpringLayout.WEST, usernameTextfield);
		spring_layout.putConstraint(SpringLayout.EAST, passwordTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(passwordTextfield);
		
		platformTextfield = new JTextField();
		spring_layout.putConstraint(SpringLayout.NORTH, platformTextfield, 6, SpringLayout.SOUTH, passwordTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, platformTextfield, 0, SpringLayout.WEST, usernameTextfield);
		spring_layout.putConstraint(SpringLayout.EAST, platformTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(platformTextfield);
		
		sqaTextfield = new JTextField();
		spring_layout.putConstraint(SpringLayout.NORTH, sqaTextfield, 6, SpringLayout.SOUTH, platformTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, sqaTextfield, 0, SpringLayout.WEST, usernameTextfield);
		spring_layout.putConstraint(SpringLayout.EAST, sqaTextfield, 0, SpringLayout.EAST, usernameTextfield);
		contentPane.add(sqaTextfield);
		
		JLabel lblEmail = new JLabel("Email:");
		spring_layout.putConstraint(SpringLayout.NORTH, lblEmail, 3, SpringLayout.NORTH, emailTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, lblEmail, 0, SpringLayout.WEST, usernameLabel);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password:");
		spring_layout.putConstraint(SpringLayout.NORTH, lblPassword, 3, SpringLayout.NORTH, passwordTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, lblPassword, 0, SpringLayout.WEST, usernameLabel);
		contentPane.add(lblPassword);
		
		JLabel lblPlatform = new JLabel("Platform:");
		spring_layout.putConstraint(SpringLayout.NORTH, lblPlatform, 3, SpringLayout.NORTH, platformTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, lblPlatform, 0, SpringLayout.WEST, usernameLabel);
		contentPane.add(lblPlatform);
		
		JLabel lblSqa = new JLabel("SQA:");
		spring_layout.putConstraint(SpringLayout.NORTH, lblSqa, 3, SpringLayout.NORTH, sqaTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, lblSqa, 0, SpringLayout.WEST, usernameLabel);
		contentPane.add(lblSqa);
		
		JButton btnAddData = new JButton("Add data");
		btnAddData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username, name, surname, email, password, platform, securityQuestionAnswer;
				username = usernameTextfield.getText();
				name = nameTextfield.getText();
				surname = surnameTextfield.getText();
				email = emailTextfield.getText();
				password = passwordTextfield.getText();
				platform = platformTextfield.getText();
				securityQuestionAnswer = sqaTextfield.getText();
				if(email==null || password==null || platform==null) {
					JOptionPane.showMessageDialog(null, "A necessary field is empty!");
				}else {
					try {
						int userID = dbControl.AddUserData(username, name, surname, email, password, platform, securityQuestionAnswer);
						JOptionPane.showMessageDialog(null, "Your user data ID is " + userID + ".");
					} catch (Exception e1) {
						System.out.println(e1.getMessage());
						e1.printStackTrace();
					}
				}
			}
		});
		spring_layout.putConstraint(SpringLayout.NORTH, btnAddData, 6, SpringLayout.SOUTH, sqaTextfield);
		spring_layout.putConstraint(SpringLayout.WEST, btnAddData, 117, SpringLayout.WEST, contentPane);
		contentPane.add(btnAddData);
		
	}
}
