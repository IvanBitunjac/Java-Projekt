import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DeleteData extends JFrame {

	private DatabaseControl databaseControl = new DatabaseControl();
	private JPanel contentPane = new JPanel();
	private SpringLayout springLayout = new SpringLayout();
	private JTextField userIDTextfield;
	
	public DeleteData() {
		setTitle("Delete data");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(290, 290);
		setContentPane(contentPane);
		contentPane.setLayout(springLayout);
		
		JLabel lblNewLabel = new JLabel("Enter User ID of data you would like to delete:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 10, SpringLayout.NORTH, contentPane);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(lblNewLabel);
		
		userIDTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, userIDTextfield, 6, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, userIDTextfield, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(userIDTextfield);
		userIDTextfield.setColumns(10);
		
		JButton btnDeleteUserData = new JButton("Delete");
		btnDeleteUserData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					int userID = Integer.parseInt(userIDTextfield.getText());
					String deleteResult;
					try {
						deleteResult = databaseControl.DeleteUserData(userID);
						if(userID == 0)
							JOptionPane.showMessageDialog(null, "User ID cannot be 0!");
						else if(deleteResult == "Data deleted")
							JOptionPane.showMessageDialog(null, "User data successfully deleted!");
						else JOptionPane.showMessageDialog(null, "No such user in database!");
					}
					catch (Exception e1) {
						e1.printStackTrace();
						System.out.println(e1.getMessage());
					}
				}
		});
		springLayout.putConstraint(SpringLayout.NORTH, btnDeleteUserData, 6, SpringLayout.SOUTH, userIDTextfield);
		springLayout.putConstraint(SpringLayout.WEST, btnDeleteUserData, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(btnDeleteUserData);
	}
}
