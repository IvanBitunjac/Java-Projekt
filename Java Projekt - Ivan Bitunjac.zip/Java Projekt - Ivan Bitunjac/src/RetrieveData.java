import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RetrieveData extends JFrame {

	private DatabaseControl databaseControl = new DatabaseControl();
	private JPanel contentPane = new JPanel();
	private SpringLayout springLayout = new SpringLayout();
	private JLabel userIDLabel;
	private JTextField userIDTextfield;
    private JTextArea userDataTextArea;
    private JButton buttonGetData;
	/**
	 * Create the frame.
	 */
	public RetrieveData() {
		setTitle("Retrieve data");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(450, 450);
		setContentPane(contentPane);
		contentPane.setLayout(springLayout);
		
		
		userIDLabel = new JLabel("User ID:");
		springLayout.putConstraint(SpringLayout.WEST, userIDLabel, 10, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.NORTH, userIDLabel, 10, SpringLayout.NORTH, contentPane);
		contentPane.add(userIDLabel);
		
		userIDTextfield = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, userIDTextfield, -3, SpringLayout.NORTH, userIDLabel);
		springLayout.putConstraint(SpringLayout.WEST, userIDTextfield, 6, SpringLayout.EAST, userIDLabel);
		springLayout.putConstraint(SpringLayout.EAST, userIDTextfield, 63, SpringLayout.EAST, userIDLabel);
		contentPane.add(userIDTextfield);
		
		userDataTextArea = new JTextArea();
		springLayout.putConstraint(SpringLayout.WEST, userDataTextArea, 10, SpringLayout.WEST, contentPane);
		springLayout.putConstraint(SpringLayout.NORTH, userDataTextArea, 10, SpringLayout.SOUTH, userIDLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, userDataTextArea, 198, SpringLayout.SOUTH, userIDLabel);
		springLayout.putConstraint(SpringLayout.EAST, userDataTextArea, 362, SpringLayout.WEST, contentPane);
		contentPane.add(userDataTextArea);
		
		buttonGetData = new JButton("Get data");
		buttonGetData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(userIDTextfield.getText() == "") {
					JOptionPane.showMessageDialog(null, "User ID is empty!");
				}
				else {
					try {
						int userID = Integer.parseInt(userIDTextfield.getText());
						if(userID == 0) {
							JOptionPane.showMessageDialog(null, "User ID cannot be 0!");
						}
						else if(databaseControl.GetUserData(userID)){
							userDataTextArea.setText(null);
							userDataTextArea.append("Username: " + databaseControl.GetResult().getString("username") + "\n");
							userDataTextArea.append("Name: " + databaseControl.GetResult().getString("name") + "\n");
							userDataTextArea.append("Surname: " + databaseControl.GetResult().getString("surname") + "\n");
							userDataTextArea.append("Email: " + databaseControl.GetResult().getString("email") + "\n");
							userDataTextArea.append("password: " + databaseControl.GetResult().getString("password") + "\n");
							userDataTextArea.append("Platform: " + databaseControl.GetResult().getString("platform") + "\n");
							userDataTextArea.append("SQA: " + databaseControl.GetResult().getString("securityQuestionAnswer") + "\n");
							userDataTextArea.append("User ID: " + databaseControl.GetResult().getInt("userID") + "\n");
						}
						else JOptionPane.showMessageDialog(null, "No such user in database!");
					}
					catch(Exception e1) {
						System.out.println(e1.getMessage());
						e1.printStackTrace();
					}
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, buttonGetData, -4, SpringLayout.NORTH, userIDLabel);
		springLayout.putConstraint(SpringLayout.WEST, buttonGetData, 14, SpringLayout.EAST, userIDTextfield);
		contentPane.add(buttonGetData);
	}
}
